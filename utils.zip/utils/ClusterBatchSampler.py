from sklearn.cluster import KMeans
from torch.utils.data import Sampler


class ClusterBatchSampler(Sampler):
    def __init__(self, indices, dist_values, batch_size, n_clusters=3, shuffle=True):
        """
        indices      : torch.arange(N)
        dist_values  : 1-D tensor, same length as indices
        """
        self.batch_size = batch_size
        self.shuffle = shuffle

        # K-means 聚类
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        clusters = kmeans.fit_predict(dist_values.reshape(-1, 1))
        self.cluster2indices = {c: [] for c in range(n_clusters)}
        for idx, c in zip(indices.tolist(), clusters):
            self.cluster2indices[c].append(idx)

        self.n_clusters = n_clusters
        self._prepare_epoch()

    def _prepare_epoch(self):
        if self.shuffle:
            for c in self.cluster2indices:
                random.shuffle(self.cluster2indices[c])
        self.cluster_iters = {c: iter(self.cluster2indices[c]) for c in self.cluster2indices}

    def __iter__(self):
        batch = []
        while True:
            for c in range(self.n_clusters):
                try:
                    batch.append(next(self.cluster_iters[c]))
                except StopIteration:
                    if batch:
                        yield batch
                    return
                if len(batch) == self.batch_size:
                    yield batch
                    batch = []
        if batch:
            yield batch

    def __len__(self):
        return (sum(len(v) for v in self.cluster2indices.values()) + self.batch_size - 1) // self.batch_size
