# utils/lightgcn_preproc.py
from typing import Optional, Union
import torch
import numpy as np

try:
    import scipy.sparse as sp
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

try:
    import networkx as nx
    _HAS_NX = True
except Exception:
    _HAS_NX = False


def _to_torch_coo(
    adj: Union[torch.Tensor, np.ndarray, "sp.spmatrix", "nx.Graph"],
    num_nodes: Optional[int] = None,
    device: Optional[torch.device] = None,
    dtype: torch.dtype = torch.float32
) -> torch.Tensor:

    if isinstance(adj, torch.Tensor):
        if adj.is_sparse:
            coo = adj.coalesce().to(dtype=dtype)
            if device is not None:
                coo = coo.to(device)
            return coo
        else:
            # dense -> coo
            if device is None:
                device = adj.device
            adj = adj.to(dtype=dtype, device=device)
            coo = adj.to_sparse_coo().coalesce()
            return coo

    if _HAS_SCIPY and sp.issparse(adj):
        # scipy.sparse -> torch coo
        coo_sp = adj.tocoo()
        if num_nodes is None:
            num_nodes = max(coo_sp.shape)
        idx = np.vstack([coo_sp.row, coo_sp.col]).astype(np.int64)
        val = coo_sp.data.astype(np.float32)
        idx_t = torch.from_numpy(idx).to(torch.long)
        val_t = torch.from_numpy(val).to(dtype)
        if device is not None:
            idx_t = idx_t.to(device)
            val_t = val_t.to(device)
        coo = torch.sparse_coo_tensor(idx_t, val_t, (num_nodes, num_nodes), device=device)
        return coo.coalesce()

    if isinstance(adj, np.ndarray):
        # numpy dense -> coo
        if num_nodes is None:
            num_nodes = max(adj.shape)
        row, col = np.nonzero(adj)
        val = adj[row, col].astype(np.float32)
        idx = np.vstack([row, col]).astype(np.int64)
        idx_t = torch.from_numpy(idx).to(torch.long)
        val_t = torch.from_numpy(val).to(dtype)
        if device is not None:
            idx_t = idx_t.to(device)
            val_t = val_t.to(device)
        coo = torch.sparse_coo_tensor(idx_t, val_t, (num_nodes, num_nodes), device=device)
        return coo.coalesce()

    if _HAS_NX and isinstance(adj, nx.Graph):
        if not _HAS_SCIPY:
            raise RuntimeError("NumPy/PyTorch。")
        coo_sp = nx.to_scipy_sparse_array(adj, nodelist=sorted(adj.nodes()), format='coo')
        return _to_torch_coo(coo_sp, num_nodes=num_nodes, device=device, dtype=dtype)

    raise TypeError(
        f"Unsupported adjacency type: {type(adj)}. "
        f"Supported: torch.Tensor, numpy.ndarray, scipy.sparse, networkx.Graph."
    )


def _remove_self_loops(adj_coo: torch.Tensor) -> torch.Tensor:
    idx = adj_coo.indices()      # [2, nnz]
    val = adj_coo.values()
    mask = (idx[0] != idx[1])
    if mask.all():
        return adj_coo
    idx = idx[:, mask]
    val = val[mask]
    out = torch.sparse_coo_tensor(idx, val, adj_coo.size(), device=adj_coo.device).coalesce()
    return out


def _add_self_loops(adj_coo: torch.Tensor, fill_value: float = 1.0) -> torch.Tensor:
    n = adj_coo.size(0)
    device = adj_coo.device
    idx_eye = torch.arange(n, device=device, dtype=torch.long)
    idx = torch.stack([idx_eye, idx_eye], dim=0)     # [2, n]
    val = torch.full((n,), float(fill_value), dtype=adj_coo.dtype, device=device)
    eye = torch.sparse_coo_tensor(idx, val, (n, n), device=device)
    out = (adj_coo + eye).coalesce()
    return out


def _symmetrize(adj_coo: torch.Tensor, mode: str = "add") -> torch.Tensor:

    A = adj_coo.coalesce()
    idx = A.indices()
    val = A.values()
    At = torch.sparse_coo_tensor(
        torch.stack([idx[1], idx[0]], dim=0), val, A.size(), device=A.device
    ).coalesce()

    if mode == "add":
        return (A + At).coalesce()
    elif mode == "mean":
        return ((A + At) * 0.5).coalesce()
    elif mode == "max":
        both = (A + At).coalesce()
        
        return both  
    else:
        raise ValueError(f"Unsupported symmetrize mode: {mode}")
# utils/indexing.py
import networkx as nx
import torch
import numpy as np

def canonicalize_two_graphs(G_a: nx.Graph, G_b: nx.Graph):

    nodes = sorted(set(G_a.nodes()) | set(G_b.nodes()))
    id2idx = {nid: i for i, nid in enumerate(nodes)}
    idx2id = nodes

    G0 = nx.relabel_nodes(G_a, id2idx, copy=True)
    G1 = nx.relabel_nodes(G_b, id2idx, copy=True)
    return G0, G1, id2idx, idx2id

def remap_id_array(arr_like, id2idx):

    if isinstance(arr_like, torch.Tensor):
        arr_np = arr_like.detach().cpu().numpy()
    else:
        arr_np = np.asarray(arr_like)

    def map_one(x):
        return id2idx[int(x)]

    vmap = np.vectorize(map_one)
    mapped = vmap(arr_np)
    mapped_t = torch.from_numpy(mapped).long()
    return mapped_t


def sym_norm_coo(
    adj_coo: torch.Tensor,
    eps: float = 1e-12
) -> torch.Tensor:

    A = adj_coo.coalesce()
    n = A.size(0)
    idx = A.indices()
    val = A.values()

    row = idx[0]
    deg = torch.zeros(n, dtype=val.dtype, device=val.device)
    deg.scatter_add_(0, row, val)

    # D^{-1/2}
    deg_inv_sqrt = torch.pow(deg + eps, -0.5)

    norm_val = val * deg_inv_sqrt[row]
    col = idx[1]
    norm_val = norm_val * deg_inv_sqrt[col]

    A_tilde = torch.sparse_coo_tensor(idx, norm_val, A.size(), device=A.device).coalesce()
    return A_tilde


def preprocess_for_lightgcn(
    adj_input: Union[torch.Tensor, np.ndarray, "sp.spmatrix", "nx.Graph"],
    num_nodes: Optional[int] = None,
    device: Optional[torch.device] = None,
    dtype: torch.dtype = torch.float32,
    make_undirected: bool = True,
    undirected_mode: str = "add",       # "add" / "mean"
    remove_self_loops: bool = True,
    add_self_loops: bool = False,       # LightGCN 
    normalize: bool = True
) -> torch.Tensor:

    A = _to_torch_coo(adj_input, num_nodes=num_nodes, device=device, dtype=dtype)
    if make_undirected:
        A = _symmetrize(A, mode=undirected_mode)     #  A <- A + A^T
    if remove_self_loops:
        A = _remove_self_loops(A)
    if add_self_loops:
        A = _add_self_loops(A, fill_value=1.0)
    if normalize:
        A = sym_norm_coo(A)
    return A.coalesce()

# utils/lightgcn_canonicalize.py
from typing import Dict, List, Tuple
import torch
import numpy as np
import networkx as nx
import scipy.sparse as sp

def build_node_indexer(G: nx.Graph) -> Tuple[List[int], Dict[int, int], Dict[int, int]]:

    nodes = list(G.nodes())               #  sorted(G.nodes())
    nodelist = nodes
    id2idx = {nid: i for i, nid in enumerate(nodelist)}
    idx2id = {i: nid for i, nid in enumerate(nodelist)}
    return nodelist, id2idx, idx2id


def remap_pairs(t: torch.Tensor, id2idx: Dict[int, int]) -> torch.Tensor:

    if not torch.is_tensor(t):
        t = torch.as_tensor(t, dtype=torch.long)
    cpu = t.detach().cpu().numpy()
    mapped = np.vectorize(lambda z: id2idx[int(z)])(cpu)
    out = torch.as_tensor(mapped, dtype=torch.long, device=t.device)
    return out


def remap_walks(walks: List[List[int]], id2idx: Dict[int, int]) -> List[List[int]]:

    return [[id2idx[int(n)] for n in path] for path in walks]


def canonicalize_all(
    G_orig: nx.Graph,
    G_gen: nx.Graph,
    node_pairs: torch.Tensor,
    negative_pairs: torch.Tensor,
    positive_pairs: torch.Tensor,
    walks: List[List[int]],
    x_pos: torch.Tensor,                 # [N, F_pos]
    x_pos_generate: torch.Tensor,        # [N, F_pos]
    x_feat: torch.Tensor = None,         # [N, F_feat]
    device: torch.device = torch.device("cpu"),
) -> dict:

    # 1) 
    nodelist, id2idx, idx2id = build_node_indexer(G_orig)

    # 2)  generated 
    G_gen = G_gen.copy()
    G_gen.add_nodes_from(nodelist)

    # 3)  nodelist 
    A_orig = nx.to_scipy_sparse_array(G_orig, nodelist=nodelist, format="coo")
    A_gen  = nx.to_scipy_sparse_array(G_gen,  nodelist=nodelist, format="coo")

    # 4)  LightGCN 
    N = len(nodelist)
    Atilde_orig = preprocess_for_lightgcn(A_orig, num_nodes=N, device=device,
                                          make_undirected=True, remove_self_loops=True,
                                          add_self_loops=False, normalize=True)
    Atilde_gen  = preprocess_for_lightgcn(A_gen,  num_nodes=N, device=device,
                                          make_undirected=True, remove_self_loops=True,
                                          add_self_loops=False, normalize=True)

    node_pairs_m      = remap_pairs(node_pairs,      id2idx)
    negative_pairs_m  = remap_pairs(negative_pairs,  id2idx)
    positive_pairs_m  = remap_pairs(positive_pairs,  id2idx)
    walks_m           = remap_walks(walks, id2idx)

    # 7) 
    def _check_max(name, tens):
        mx = int(tens.max().item()) if tens.numel() > 0 else -1
        assert mx < N, f"{name} has id {mx} >= N={N}"

    _check_max("node_pairs",     node_pairs_m)
    _check_max("negative_pairs", negative_pairs_m)
    _check_max("positive_pairs", positive_pairs_m)

    out = dict(
        Atilde_orig=Atilde_orig,
        Atilde_gen=Atilde_gen,
        node_pairs=node_pairs_m,
        negative_pairs=negative_pairs_m,
        positive_pairs=positive_pairs_m,
        walks=walks_m,
        x_pos=x_pos.to(device),
        x_pos_generate=x_pos_generate.to(device),
        x_feat=(x_feat.to(device) if x_feat is not None else None),
        nodelist=nodelist,
        id2idx=id2idx,
        idx2id=idx2id,
        N=N,
    )
    return out

