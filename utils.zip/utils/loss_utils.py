import math as _math
import torch
import torch.nn.functional as F
import torch.nn as nn
# from dne_structlosslocalglobal_loss import log_sum_exp,get_negative_expectation,get_positive_expectation
class ContrastiveMutualInfoDiscriminator(nn.Module):
    def __init__(self, hidden_dim, temperature=0.1):
        super(ContrastiveMutualInfoDiscriminator, self).__init__()
        self.temperature = temperature
        # 
        self.local_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        self.global_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
    def forward(self, local_repr, global_repr, negative_global_repr=None):
        """
        local_repr: [batch_size, hidden_dim]
        global_repr: [batch_size, hidden_dim] 
        negative_global_repr: [batch_size, num_negatives, hidden_dim] 或 None
        """
        # 
        proj_local = F.normalize(self.local_proj(local_repr), dim=1)
        proj_global = F.normalize(self.global_proj(global_repr), dim=1)
        
        # 
        positive_similarity = torch.sum(local_repr * global_repr, dim=1) / self.temperature
        
        if negative_global_repr is not None:
            # 
            proj_negative_global = F.normalize(self.global_proj(negative_global_repr), dim=2)
            negative_similarity = torch.bmm(
                proj_local.unsqueeze(1), 
                proj_negative_global.transpose(1, 2)
            ).squeeze(1) / self.temperature
            
            # 
            logits = torch.cat([
                positive_similarity.unsqueeze(1), 
                negative_similarity
            ], dim=1)
            
            labels = torch.zeros(local_repr.size(0), dtype=torch.long).to(local_repr.device)
            loss = F.cross_entropy(logits, labels)
            return loss
        else:
            # 
            return torch.sigmoid(positive_similarity / self.temperature)
        
def get_positive_expectation(p_samples, measure, average=True):
    """Computes the positive part of a divergence / difference.

    Args:
        p_samples: Positive samples.
        measure: Measure to compute for.
        average: Average the result over samples.

    Returns:
        torch.Tensor

    """
    log_2 = _math.log(2.)

    if measure == 'GAN':
        Ep = - F.softplus(-p_samples)
    elif measure == 'JSD':
        Ep = log_2 - F.softplus(- p_samples)
    elif measure == 'X2':
        Ep = p_samples ** 2
    elif measure == 'KL':
        Ep = p_samples + 1.
    elif measure == 'RKL':
        Ep = -torch.exp(-p_samples)
    elif measure == 'DV':
        Ep = p_samples
    elif measure == 'H2':
        Ep = 1. - torch.exp(-p_samples)
    elif measure == 'W1':
        Ep = p_samples
    else:
        raise_measure_error(measure)

    if average:
        return Ep.mean()
    else:
        return Ep
def raise_measure_error(measure):
    supported_measures = ['GAN', 'JSD', 'X2', 'KL', 'RKL', 'DV', 'H2', 'W1']
    raise NotImplementedError(
        'Measure `{}` not supported. Supported: {}'.format(measure,
                                                           supported_measures))

import torch
import torch.nn.functional as F

# from cortex_DIM.functions.misc import log_sum_exp
def log_sum_exp(x, axis=None):
    """Log sum exp function

    Args:
        x: Input.
        axis: Axis over which to perform sum.

    Returns:
        torch.Tensor: log sum exp

    """
    x_max = torch.max(x, axis)[0]
    y = torch.log((torch.exp(x - x_max)).sum(axis)) + x_max
    return y

def get_negative_expectation(q_samples, measure, average=True):
    """Computes the negative part of a divergence / difference.

    Args:
        q_samples: Negative samples.
        measure: Measure to compute for.
        average: Average the result over samples.

    Returns:
        torch.Tensor

    """
    log_2 = _math.log(2.)
    if measure == 'GAN':
        Eq = F.softplus(-q_samples) + q_samples
    elif measure == 'JSD':
        Eq = F.softplus(-q_samples) + q_samples - log_2
    elif measure == 'X2':
        Eq = -0.5 * ((torch.sqrt(q_samples ** 2) + 1.) ** 2)
    elif measure == 'KL':
        Eq = torch.exp(q_samples)
    elif measure == 'RKL':
        Eq = q_samples - 1.
    elif measure == 'DV':
        Eq = log_sum_exp(q_samples, 0) - _math.log(q_samples.size(0))
    elif measure == 'H2':
        Eq = torch.exp(q_samples) - 1.
    elif measure == 'W1':
        Eq = q_samples
    else:
        raise_measure_error(measure)

    if average:
        return Eq.mean()
    else:
        return Eq


def mutual_information_maximization(local_repr, context_repr, temperature=0.1):
    batch_size = local_repr.shape[0]
    
    #  (local_i, context_i)
    positive_scores = F.cosine_similarity(local_repr, context_repr, dim=-1) / temperature
    
    #  (local_i, context_j) where j != i
    negative_scores = torch.mm(local_repr, context_repr.t()) / temperature  # [batch, batch]
    
    # 
    labels = torch.arange(batch_size).to(local_repr.device)
    
    # 
    loss = F.cross_entropy(negative_scores, labels)
    
    return loss

# ======  ======
def cross_view_loss_for_pairs(global_orig, global_gen, measure='JSD'):
    num_pairs = global_orig.shape[0]
    pos_mask = torch.eye(num_pairs).to(global_orig.device)
    neg_mask = 1 - pos_mask
    res = torch.mm(global_orig, global_gen.t())
    E_pos = get_positive_expectation(res * pos_mask, measure, average=False).sum() / num_pairs
    E_neg = get_negative_expectation(res * neg_mask, measure, average=False).sum() / (num_pairs * (num_pairs - 1))
    return E_neg - E_pos

def local_global_loss_for_pairs(l_enc, g_enc, batch,num_negatives, measure='JSD'):
    num_nodes = l_enc.shape[0]
    positive_scores = []
    negative_scores = []
    for node_idx, graph_idx in enumerate(batch):
        pos_score = torch.dot(l_enc[node_idx], g_enc[graph_idx])
        positive_scores.append(pos_score)
        neg_indices = torch.randint(0, g_enc.shape[0], (num_negatives,)).to(l_enc.device)
        neg_indices = neg_indices[neg_indices != graph_idx]
        neg_scores = torch.matmul(l_enc[node_idx].unsqueeze(0), g_enc[neg_indices].t()).squeeze()
        negative_scores.append(neg_scores)
    E_pos = get_positive_expectation(torch.stack(positive_scores), measure).mean()
    E_neg = get_negative_expectation(torch.cat(negative_scores), measure).mean()
    return E_neg - E_pos

def compute_node_pair_contrastive_loss(local_repr, struct_original, struct_generated, pair_indices):
    losses = {}
    batch_size = local_repr.shape[0]
    
    if struct_original is not None:
        pseudo_batch = torch.arange(batch_size)
        losses['local_struct_original'] =local_global_loss_for_pairs(
            local_repr, struct_original, pseudo_batch, measure='JSD')
    
    if struct_generated is not None:
        pseudo_batch = torch.arange(batch_size)
        losses['local_struct_generated'] = local_global_loss_for_pairs(
            local_repr, struct_generated, pseudo_batch, measure='JSD')
    
    if struct_original is not None and struct_generated is not None:
        losses['cross_view'] = cross_view_loss_for_pairs(
            struct_original, struct_generated, measure='JSD')
    
    return losses

# ======  ======
@staticmethod
def _bn(z, eps=1e-4):
    z = z - z.mean(dim=0, keepdim=True)
    std = z.std(dim=0, keepdim=True) + eps
    return z / std

@staticmethod
def _xcorr(Z1, Z2):
    B = Z1.size(0)
    return (Z1.t() @ Z2) / B

@staticmethod
def _var_loss(Z, eps=1e-4):
    std = Z.std(dim=0) + eps
    return torch.mean(torch.relu(1.0 - std) ** 2)


