# utils_sampler.py  ()
import random, torch

class StratifiedBatchSampler(torch.utils.data.Sampler):

    def __init__(self,
                 indices: torch.Tensor,
                 dist_values: torch.Tensor,
                 batch_size: int,
                 n_bins: int = 3,
                 shuffle: bool = True):
        self.batch_size = batch_size
        self.n_bins = n_bins
        self.shuffle = shuffle

        # 1) 
        q = torch.quantile(dist_values,
                           torch.linspace(0, 1, n_bins + 1))
        self.bin2idx = {b: [] for b in range(n_bins)}
        for idx, d in zip(indices.tolist(), dist_values.tolist()):
            b = min(int(torch.bucketize(torch.tensor([d]), q)[0]) - 1,
                    n_bins - 1)
            self.bin2idx[b].append(idx)

        self._prepare_epoch()

    def _prepare_epoch(self):
        if self.shuffle:
            for b in self.bin2idx:
                random.shuffle(self.bin2idx[b])
        # 
        self.bin_iters = {b: iter(lst) for b, lst in self.bin2idx.items()}

    def __iter__(self):
        batch = []
        while True:
            finished_bins = 0
            for b in range(self.n_bins):
                try:
                    batch.append(next(self.bin_iters[b]))
                except StopIteration:
                    finished_bins += 1
                    continue
                if len(batch) == self.batch_size:
                    yield batch
                    batch = []
            if finished_bins == self.n_bins:   # 
                if batch:          #  batch_size 
                    yield batch
                break

    def __len__(self):
        total = sum(len(v) for v in self.bin2idx.values())
        return (total + self.batch_size - 1) // self.batch_size

    def set_epoch(self):
        self._prepare_epoch()
